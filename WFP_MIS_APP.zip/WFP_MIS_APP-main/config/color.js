export default {
  primary: "#fc5c65",
  secondary: "#4ecdc4",
};
